# SEOImpuls — source repository

Private development repository for https://seoimpuls.com/.

## Baseline

Source is taken from the 2026-10-15 server export, `Seoimpuls/source/`.
The archive also contained `server-current/public/`, captured from the active release on the VPS, but generated site files are intentionally not tracked in this repository.

The existing, historically deployed site may still include high-risk link-selling and automated-placement content. The original version is an **unmodified baseline, not approved for new publication**.

## Local development

Requires Hugo Extended `0.154.5` and Go `1.25.5` (versions used in export validation).

```bash
hugo --minify
hugo server --disableFastRender
```

The bundled `_vendor/` theme is retained for reproducibility.
The local admin UI is optional; its deployment credentials are not committed.

## Change policy

1. Preserve the baseline on `main` until the rebuild is independently validated.
2. Make all white-hat SEO, design and content changes on `white-seo-rebuild`.
3. No GitHub Pages / auto-deploy, no production server writes.
4. Preserve existing valuable URLs until canonical / redirect mapping is approved.
5. Do not replace prohibited offerings by euphemisms: genuinely remove them from the service catalog and supporting claims.
6. English page is the structural reference; localize RU/ES by native search intent.
7. Never commit secrets, origin server settings, user credentials, or local research unrelated to this site.

See [docs/REBUILD_PLAN.md](docs/REBUILD_PLAN.md) and [docs/IMPORT_AUDIT.md](docs/IMPORT_AUDIT.md).
